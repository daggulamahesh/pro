import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {  Observable } from 'rxjs';
import { Cart } from './Cart';
import { ViewCart } from './ViewCart';
import { $ } from 'protractor';
import { TransactionEntity } from './transaction';
import { Buyer } from './Buyer';
import { ApiResponse } from './model/api.response';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private baseUrl2='http://localhost:8918/api1/Buyer'
  private baseUrl = 'http://localhost:8917/itemapi/getallbyname';
  private baseUrl1 = 'http://localhost:8918/api/getall';

  login(loginPayload) : Observable<ApiResponse> {
    return this.http.post<ApiResponse>('http://localhost:8918/' + 'token/generate-token', loginPayload);
  }
  constructor(private http:HttpClient) { }

addTocart(buyerid:number,cart:Cart): Observable<any>
{
  return this.http.post(`http://localhost:8918/api/additem/${buyerid}`,cart);
}
 

getItem(searchstr:string) : Observable<any>
{

  return this.http.get(`${this.baseUrl}/${searchstr}`);
}
getcartitems(id:any):Observable<any>
  {   
    
      console.log("in service method");
      return this.http.get(`http://localhost:8918/api/getall/${id}`);
  }
  


  updateCartItem(view:ViewCart):Observable<any>
  {

    console.log(view);
    return this.http.put(`http://localhost:8918/api/update`,view);
  }
  deletecartitem(i:number) :Observable<any>
  {
    console.log("service method"+i);
  return  this.http.delete(`http://localhost:8918/api/deleteitem/${i}`);
  }

  getitembysubcatagory(id:number):Observable<any>
  {
   return  this.http.get(`http://localhost:8917/itemapi/getbysubid/${id}`);
  }
  getitembyid(id:number) :Observable<any>
  {
    return this.http.get(`http://localhost:8917/itemapi/item/${id}`)

  }

  createbuyer(buyer:Buyer) :Observable<any>
  {
    console.log("createBuyer");
  return this.http.post(`${this.baseUrl2}`,buyer)

  }
 checkout(id:number,transaction:TransactionEntity):Observable<any>
 {


   console.log("servicechecout"+id);
   console.log(transaction);
   return this.http.post(`http://localhost:8918/api/checkout/${id}`,transaction);
 }
  
}




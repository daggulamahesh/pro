export class Cart
{
    cartId:number;
    itemId:number;
    noOfItems:number=1;
    buyer:any;
    price:number;
    description:string;
}
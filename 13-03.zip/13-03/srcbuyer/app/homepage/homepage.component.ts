import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { ProductService } from '../product.service';
import { Item } from '../Item';
import { Router } from '@angular/router';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {

  constructor(private productservice:ProductService ,private  router:Router) { }
item:Item[];


  //id=3;

  ngOnInit(): void {
this.productservice.getitembysubcatagory(1).subscribe(item=>this.item=item);
 // console.log(this.item)
  }

  // @Output() messageEvent = new EventEmitter<number>();
  // sendMessage(id:number) {
  //   console.log("sendmessage"+id);
  //   this.messageEvent.emit(id);
  //   this.router.navigate(['card']);
  // }
  ProductDetails(id:number)
  {

   this.router.navigate(['card',id]);
  }

}

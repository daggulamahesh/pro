import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Buyer } from './Buyer';
import { Observable } from 'rxjs';
import { TransactionEntity } from './transaction';

@Injectable({
  providedIn: 'root'
})
export class BuyerService {

  //private baseUrl2='http://localhost:8918/api1/Buyer'
  constructor( private http:HttpClient) { }
  

//   createbuyer(buyer:Buyer) :Observable<any>
//   {
//     console.log("createBuyer");
//   return this.http.post(`${this.baseUrl2}`,buyer)

//   }
//  checkout(id:number,transaction:TransactionEntity):Observable<any>
//  {


//    console.log("servicechecout"+id);
//    console.log(transaction);
//    return this.http.post(`http://localhost:8918/api/checkout/${id}`,transaction);
//  }
}

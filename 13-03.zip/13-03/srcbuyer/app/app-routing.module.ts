import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { SearchProductComponent } from './search-product/search-product.component';
import { DisplayCartComponent } from './display-cart/display-cart.component';
import { SingupComponent } from './singup/singup.component';
import { HomepageComponent } from './homepage/homepage.component';
import { CardComponent } from './card/card.component';
import { TransactionComponent } from './transaction/transaction.component';
import { LoginformComponent } from './loginform/loginform.component';
import { combineLatest } from 'rxjs';
import { LogoutComponent } from './logout/logout.component';
import { AuthGuard } from './auth.guard';



const routes: Routes = [
  {path:'',component:HomepageComponent},
  {path:'product-details',component:ProductDetailsComponent  },
  {path:'search-details', component:SearchProductComponent},
  {path:'display-cart',component:DisplayCartComponent,canActivate:[AuthGuard]},
  {path:'singup',component:SingupComponent},
  {path:'homepage',component:HomepageComponent},
  {path:'card/:id',component:CardComponent},
  {path:'gototransaction',component:TransactionComponent},
  {path:'login',component:LoginformComponent},
  {path:'logout',component:LogoutComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

package com.egg.service;

import java.util.List;

import java.util.Optional;

import com.egg.model.Item;



public interface ItemSerivce {
	
	
	Optional<Item> addItem(Item item ,Integer id);
	Item updateItem(Item item,Integer id);
	List<Item> getAllBysellerid( Integer id);
	Item getbyid(Integer id);
	 List<Item> getAllByitemName(String itemname);
	 void deleteItem(Integer id);
	 List<Item> getBysubcategoryid(Integer id);
	 
	
}

package com.egg.model;

public class AuthToken {

    private String token;
    private String username;
    private int sellerid;
    

    public int getSellerid() {
		return sellerid;
	}

	public void setSellerid(int sellerid) {
		this.sellerid = sellerid;
	}

	public AuthToken(){

    }

    public AuthToken(String token, String username, int sellerid) {
			this.token = token;
		this.username = username;
		this.sellerid = sellerid;
	}

    public AuthToken(String token){
        this.token = token;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}

package com.egg.service;

import java.util.Arrays;

import java.util.List;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.egg.dao.SellerDao;
import com.egg.model.SellerEntity;

@Service(value = "userService")
public class SelllerImplemention  implements SellerService,UserDetailsService {

	@Autowired
	SellerDao sellerdao;
	
	
	
	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		SellerEntity seller = sellerdao.findByusername(username);
		if(seller == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(seller.getUsername(), seller.getPassword(), getAuthority());
	}

	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
	}

	
	
	
	
	@Override
	public SellerEntity addSeller(SellerEntity seller) {
		
		 seller.setPassword(bcryptEncoder.encode(seller.getPassword()));
		return sellerdao.save(seller);
	}

	@Override
	public SellerEntity updateSeller(SellerEntity seller, Integer id) {
		
		Optional<SellerEntity> sellerobject=sellerdao.findById(id);
		SellerEntity  sellerinsert=null;
		if(sellerobject.isPresent())
		{  sellerinsert= sellerobject.get();
			sellerinsert.setUsername(seller.getUsername());
		//	sellerinsert.setPassword(bcryptEncoder.encode(seller.getPassword()));
			sellerinsert.setCompanyname(seller.getCompanyname());
			sellerinsert.setGstin(seller.getGstin());
			sellerinsert.setBriefaboutcompany(seller.getBriefaboutcompany());
			sellerinsert.setWebsite(seller.getWebsite());
			sellerinsert.setEmailId(seller.getEmailId());
			sellerinsert.setContactnumber(seller.getContactnumber());
			sellerinsert.setPostaladdress(seller.getPostaladdress());
			
			sellerinsert = sellerdao.save(sellerinsert);
		}
		return sellerinsert;
		
	}

	@Override
	public List<SellerEntity> gettAll() {
		
		return sellerdao.findAll();
	}

	@Override
	public SellerEntity getById(Integer id) {
	
		Optional<SellerEntity> seller = sellerdao.findById(id);
		 return seller.isPresent() ? seller.get(): null;
	}
	

	@Override
	public SellerEntity findOne(String username) {
		
		
		return sellerdao.findByusername(username);
	}


	

	
}

package com.example.jpa.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.springframework.data.annotation.CreatedDate;

@Entity
@Table(name="Transaction")
public class TransactionEntity extends AuditModel implements Serializable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer transactionId;
	
	private String transactionType;
	 
	//private Date dateTime;
	private String tranRemarks;
	private float totalamount;
	
	
	
	
	
	public float getTotalamount() {
		return totalamount;
	}
	public void setTotalamount(float totalamount) {
		this.totalamount = totalamount;
	}

	@ManyToOne(cascade = {CascadeType.ALL}) /* (fetch = FetchType.LAZY, optional = false) */  
	  @JoinColumn(name = "buyerId", nullable = false)
	//  @OnDelete(action = OnDeleteAction.CASCADE)
	  private BuyerEntity buyerentity;
	  
	  public BuyerEntity getBuyerentity()
	  { return buyerentity; } 
	  public void  setBuyerentity(BuyerEntity buyerentity) 
	  { 
		  this.buyerentity = buyerentity;
	  }
	 
	public Integer getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}
	
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	
	public String getTranRemarks() {
		return tranRemarks;
	}
	public void setTranRemarks(String tranRemarks) {
		this.tranRemarks = tranRemarks;
	}
	public TransactionEntity(Integer transactionId, String transactionType, String tranRemarks) {
		super();
		this.transactionId = transactionId;
		
		this.transactionType = transactionType;
		this.tranRemarks = tranRemarks;
	}
	
	public TransactionEntity()
	{
		
	}
	

}

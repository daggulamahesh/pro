package com.example.jpa.service;

public class PostService {

}

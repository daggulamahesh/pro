package com.example.jpa.controller;

import javax.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.jpa.model.TransactionEntity;
import com.example.jpa.service.TransactionImplementation;

//import com.cts.Entity.TransactionEntity;
//import com.cts.Service.TransactionImplementation;

@RestController
public class TransactionController {
	
	@Autowired
	private TransactionImplementation transactionservice;
	
	/*
	 * @GetMapping("/Buyer/{buyerId}/Transaction") public Page<TransactionEntity>
	 * findByBuyerId(@PathVariable (value = "buyerId") Integer buyerid, Pageable
	 * pageable) { return transactionservice.findByBuyerId(buyerid, pageable); }
	 */
	  
	  @PostMapping("/Buyer/{buyerId}/Transaction")
	  public TransactionEntity createTransaction(@PathVariable (value = "buyerId") int buyerid,
              @Valid @RequestBody TransactionEntity transaction )
	  {
		  
		  return transactionservice.createTransaction(buyerid, transaction);
	  }

	
	
	
	

}
